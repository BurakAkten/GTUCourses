import java.lang.Error;
/**
 *
 * @author Burak Akten
 */
public interface LibraryManagmentSys {
    /**
     *
     * @param choice the choice of library management system users. 
     * @throws Error when any Error showed up.
     */
    public void run(int choice)throws Error;
}